package graphics;
import java.awt.Color;
import java.awt.Graphics;
/**
 * @author Héctor Quej Cosgaya
 * @author Jose Aguilar Canepa
 * 
 * Esta clase necesita de tu ayuda!
 */
public class Rectangulo extends FiguraGrafica {
    
    private int x = 15;
    private int y = 15;
    private int ancho = 70;
    private int alto = 35;

    public void dibujar(Graphics g) {
        g.drawRect(x, y, ancho, alto);
    }

    public void encojer(Graphics g) {
        ancho -= 5;
        alto -= 5;
        if (ancho < 5) ancho = 5;
        if (alto < 5) alto = 5;
        this.dibujar(g);
    }

    public void agrandar(Graphics g) {
        ancho += 5;
        alto += 5;
        if (ancho > 200) ancho = 200;
        if (alto > 200) alto = 200;
        this.dibujar(g);
    }

    public void cambiarColor(Graphics g, Color c) {
        g.setColor(c);
        this.dibujar(g);
    }

    public void mover(Graphics g, String direccion) {
        switch(direccion) {
            case "arriba" : y -= 5; break;
            case "abajo" : y += 5; break;
            case "izquierda" : x -= 5; break;
            case "derecha" : x += 5; break;
        }
        this.dibujar(g);
    }

    @Override
    public void FiguraGrafica() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void FiguraGrafica(String figura) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
